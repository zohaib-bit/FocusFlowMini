//
//  FlowFocusMiniApp.swift
//  FlowFocusMini
//
//  Created by o9tech on 11/11/2025.
//

import SwiftUI

@main
struct FlowFocusMiniApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
